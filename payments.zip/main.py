import mysql.connector as connection
import pandas as pd
from google.cloud import bigquery
import mysql

def fn_raw_payments(request):

    request_arg = request.args
    prj = request_arg['prj']

    mydb = mysql.connector.connect(
      host="35.235.114.148",
      user="root",
      password="123qaz456",
      database="classicmodels"
    )
    query = "SELECT * FROM classicmodels.payments;"
    result_dataFrame = pd.read_sql(query,mydb)
    mydb.close()

    client = bigquery.Client()

    table_id =prj+".ma_dlake_dev_raw.payments"

    job_config = bigquery.LoadJobConfig(
        schema=[
            bigquery.SchemaField("customerNumber", "INTEGER"),
            bigquery.SchemaField("checkNumber", "STRING"),
            bigquery.SchemaField("paymentDate", "DATE"),
            bigquery.SchemaField("amount", "FLOAT64"),
        ],
        write_disposition="WRITE_TRUNCATE",
    )

    job = client.load_table_from_dataframe(
    result_dataFrame, table_id, job_config=job_config)
    return "Listo"
