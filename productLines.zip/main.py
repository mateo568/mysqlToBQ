import mysql.connector as connection
import pandas as pd
from google.cloud import bigquery
import mysql

def fn_raw_productlines(request):

    request_arg = request.args
    prj = request_arg['prj']

    mydb = mysql.connector.connect(
      host="35.235.114.148",
      user="root",
      password="123qaz456",
      database="classicmodels"
    )
    query = "SELECT * FROM classicmodels.productlines;"
    result_dataFrame = pd.read_sql(query,mydb)
    mydb.close()

    client = bigquery.Client()

    table_id =prj+".ma_dlake_dev_raw.productlines"

    job_config = bigquery.LoadJobConfig(
        schema=[
            bigquery.SchemaField("productLine", "STRING"),
            bigquery.SchemaField("textDescription", "STRING"),
            bigquery.SchemaField("htmlDescription", "STRING"),
            bigquery.SchemaField("image", "STRING"),
        ],
        write_disposition="WRITE_TRUNCATE",
    )

    job = client.load_table_from_dataframe(
    result_dataFrame, table_id, job_config=job_config)
    return "Listo"
