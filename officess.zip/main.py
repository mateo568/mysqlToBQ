import mysql.connector as connection
import pandas as pd
from google.cloud import bigquery
import mysql

def fn_raw_offices(request):

    request_arg = request.args
    prj = request_arg['prj']

    mydb = mysql.connector.connect(
      host="35.235.114.148",
      user="root",
      password="123qaz456",
      database="classicmodels"
    )
    query = "SELECT * FROM classicmodels.offices;"
    result_dataFrame = pd.read_sql(query,mydb)
    mydb.close()

    client = bigquery.Client()

    table_id =prj+".ma_dlake_dev_raw.offices"

    job_config = bigquery.LoadJobConfig(
        schema=[
            bigquery.SchemaField("officeCode", "STRING"),
            bigquery.SchemaField("city", "STRING"),
            bigquery.SchemaField("phone", "STRING"),
            bigquery.SchemaField("addressLine1", "STRING"),
            bigquery.SchemaField("addressLine1", "STRING"),
            bigquery.SchemaField("state", "STRING"),
            bigquery.SchemaField("country", "STRING"),
            bigquery.SchemaField("postalCode", "STRING"),
            bigquery.SchemaField("territory", "STRING"),
        ],
        write_disposition="WRITE_TRUNCATE",
    )

    job = client.load_table_from_dataframe(
    result_dataFrame, table_id, job_config=job_config)
    return "Listo"