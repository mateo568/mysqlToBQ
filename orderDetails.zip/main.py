from googleapiclient.discovery import build
from google.cloud import bigquery

def loadOrderDetails(event, context):
    client = bigquery.Client();

    tabla_bq = "orderDetails";
    table_id = "datapath-376823.ma_dlake_dev_raw.orderDetails";

    job_config = bigquery.LoadJobConfig(
        schema=[
            bigquery.SchemaField("orderNumber","INTEGER"),
            bigquery.SchemaField("productCode","STRING"),
            bigquery.SchemaField("quantityOrdered","INTEGER"),
            bigquery.SchemaField("priceEach","NUMERIC"),
            bigquery.SchemaField("orderLineNumber","INTEGER")
        ],
        skip_leading_rows=1,
        write_disposition=bigquery.WriteDisposition.WRITE_TRUNCATE,
        source_format=bigquery.SourceFormat.CSV,
    )
    job_config.field_delimiter = ";"
    uri = "gs://ma_dlake_dev_raw/orderdetails.csv"
    load_job = client.load_table_from_uri(
        uri, table_id, job_config=job_config
    )